public class SortingWithNewOrdering {
        In orderingFile = new In("NewOrdering.txt");
        In inputFile = new In("InputNewOrdering.txt");

        Out outputFile = new Out("OutputNewOrdering.txt");
        public static void main(String[] args){



        }

}
