public class StockMarket{
        In inputFile = new In("StockDealsInput.txt");
        Out outputFile = new Out("TransitionOutput.txt");
        public static void main(String[] args){
    
        }
}
