package tr.edu.sehir.oop;
import javax.swing.*;
import java.io.IOException;
import java.net.ServerSocket;

public class ServerT{

    ServerSocket server;

    public void startServerT(){
        try{
            server = new ServerSocket(4321);
        } catch (IOException e) {
            System.out.println("Could not listen on port 4321");
            System.exit(-1);
        }
        while(true){
            ClientWorker w;
            try{
//server.accept returns a client connection
                w = new ClientWorker(server.accept());
                Thread t = new Thread(w);
                t.start();
            } catch (IOException e) {
                System.out.println("Accept failed: 4444");
                System.exit(-1);
            }
        }
    }
}