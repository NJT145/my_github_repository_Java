package tr.edu.sehir.oop;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        ServerT sT = new ServerT();
        sT.startServerT();
    }
}
